package com.example.aditya.gvpattendance;

import android.util.Log;

/**
 * Created by Aditya on 28-02-2018.
 */

public class MainPageContents {

    private String title ;
    private String desc ;
    private String timehour;
    private int sem;
    private int image;

    public MainPageContents(String title, String desc, int image) {

        this.title = title;
        this.desc = desc;
        this.image = image;

    }
    public MainPageContents(String title, String desc, String timehour,int sem ) {

        this.title = title;
        this.desc = desc;
        this.timehour = timehour;
        this.sem = sem;
        //this.image = image;

    }

    public String getTitle() {return title;}

    public String getDesc() {
        return desc;
    }

    public String getTimehour() {
        return timehour;
    }

    public int getSem() {
        return sem;
    }

    public int getImage() { return image; }
}
