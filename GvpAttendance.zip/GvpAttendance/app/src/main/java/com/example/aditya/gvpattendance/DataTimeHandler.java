package com.example.aditya.gvpattendance;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Created by Aditya on 15-03-2018.
 */

public class DataTimeHandler {
    public String weekDay , TodayDate;

    SimpleDateFormat dayFormat = new SimpleDateFormat("d/MM/yy ,EEEE", Locale.getDefault());
    SimpleDateFormat weekName = new SimpleDateFormat("E" , Locale.getDefault());
    Calendar calendar = Calendar.getInstance();

    public DataTimeHandler(){
        TodayDate = dayFormat.format(calendar.getTime());
        weekDay = weekName.format(calendar.getTime());
    }

    public String getTodayDate(){

        return TodayDate;
    }
    public  String getWeekDay(){

        return weekDay;
    }
}
