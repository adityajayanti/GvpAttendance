package com.example.aditya.gvpattendance;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Aditya on 28-02-2018.
 */

public class ContentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<MainPageContents> contentlist;
    private OnItemClickListener mListener;
    private int ActivityviewType;

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public void setItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public ContentsAdapter(Context context, List<MainPageContents> contentlist , int vt) {
        this.context = context;
        this.contentlist = contentlist;
        this.ActivityviewType = vt;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        switch (ActivityviewType) {

            case 0:
                   View view = inflater.inflate(R.layout.list_layout,null);
                   return new ViewHolder0(view ,mListener);

            case 1:
                   View view1 = inflater.inflate(R.layout.subject_list_layout,null);
                   return new ViewHolder2(view1 ,mListener);

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final MainPageContents mainPageContents = contentlist.get(position);
        switch (holder.getItemViewType()) {
            case 0:
                ViewHolder0 viewHolder0 = (ViewHolder0)holder;
                viewHolder0.textViewTitle.setText(mainPageContents.getTitle());
                viewHolder0.textViewDesc.setText(mainPageContents.getDesc());
                viewHolder0.imageView.setImageDrawable(context.getResources().getDrawable(mainPageContents.getImage()));
                viewHolder0.textView.setText("");
                break;

            case 1:
                ViewHolder2 viewHolder2 = (ViewHolder2)holder;
                viewHolder2.textViewTitle.setText(mainPageContents.getTimehour());
                viewHolder2.textView.setText(" hour - "+mainPageContents.getDesc());
                //viewHolder2.imageView.setImageDrawable(context.getResources().getDrawable(mainPageContents.getImage()));
                viewHolder2.textViewDesc.setText(" "+mainPageContents.getTitle()+" "+String.valueOf(mainPageContents.getSem()+" Sem"));
                break;
        }




    }

    @Override
    public int getItemCount() {
        return contentlist.size()>0?contentlist.size():1;
    }

    @Override
    public int getItemViewType(int position) {
        return ActivityviewType;
    }

    class ViewHolder0 extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView textViewTitle , textViewDesc ,textView;
        RelativeLayout relativeLayout;

        public ViewHolder0(View itemView , final OnItemClickListener listener) {

            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDesc = itemView.findViewById(R.id.textViewDesc);
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textViewCheck);
            relativeLayout = itemView.findViewById(R.id.relativelayout);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position !=RecyclerView.NO_POSITION){
                             listener.onItemClick(position);
                        }

                    }
                }
            });
        }


    }

    class ViewHolder2 extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView textViewTitle , textViewDesc ,textView;
        RelativeLayout relativeLayout;

        public ViewHolder2(View itemView , final OnItemClickListener listener) {

            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDesc = itemView.findViewById(R.id.textViewDesc);
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textViewCheck);
            relativeLayout = itemView.findViewById(R.id.relativelayout);
            relativeLayout.removeView(imageView);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position !=RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }

                    }
                }
            });
        }


    }
    }


