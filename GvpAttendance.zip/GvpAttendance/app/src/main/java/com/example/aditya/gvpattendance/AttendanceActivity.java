package com.example.aditya.gvpattendance;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class AttendanceActivity extends AppCompatActivity {
    DataTimeHandler dataTimeHandler;
    TextView textdept , textsem , textsub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        dataTimeHandler = new DataTimeHandler();
        getSupportActionBar().setTitle(dataTimeHandler.getTodayDate().toString());


        textdept = (TextView)findViewById(R.id.TextDept);
        textsem = (TextView)findViewById(R.id.TextSem);
        textsub = (TextView)findViewById(R.id.TextSub);

        Intent intent =getIntent();
        textdept.setText(intent.getStringExtra("dept").toString());
        textsem.setText(intent.getStringExtra("sem").toString());
        textsub.setText(intent.getStringExtra("sub").toString());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.features_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){

            case R.id.Logout:
                SharedPrefManager.getInstance(this).islogout();
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                break;
            case R.id.backto:
                startActivity(new Intent(getApplicationContext(), Main2Activity.class));
                break;


        }
        return  true;

    }
}
