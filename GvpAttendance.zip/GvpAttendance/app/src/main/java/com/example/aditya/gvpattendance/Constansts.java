package com.example.aditya.gvpattendance;

/**
 * Created by Aditya on 26-02-2018.
 */

public class Constansts {
    private static final String RootURl = "http://192.168.1.33:10080/Android/v1/";

    //public static final String RegURL = RootURl+"registerUser.php";

    public static  final String LogURL = RootURl+"loginUser.php";

    public static final  String TimeTableURL = RootURl+"timetableUser.php";
}
